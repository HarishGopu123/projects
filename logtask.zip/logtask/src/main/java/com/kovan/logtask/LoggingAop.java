package com.kovan.logtask;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Aspect
@Component
@Slf4j
public class LoggingAop {

    @Before("@annotation(Logging)")
    public void logExecutionTime(JoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method=signature.getMethod();
        Logging logging=method.getAnnotation(Logging.class);
        if(logging.value()) {
            log.info("Logging Student Info :-  " + (joinPoint.getArgs()[0]).toString());
        }
    }

}
