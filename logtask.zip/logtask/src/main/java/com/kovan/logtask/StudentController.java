package com.kovan.logtask;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class StudentController {

@Logging
@PostMapping("/student")
@ResponseStatus(HttpStatus.OK)
public Student createStudent(@RequestBody() Student student) {
   return student;
}


}
