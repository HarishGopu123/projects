package com.kovan.logtask;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
public class StudentLogController {

@Logging(value = true)
@PostMapping("/student/log")
@ResponseStatus(HttpStatus.OK)
public Student createStudentLog(@RequestBody() Student student) {
    return student;
}

}
